-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: book_library
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `Book_ID` int NOT NULL,
  `Classification_ID` int DEFAULT NULL,
  `Book_Title` mediumtext,
  `Author` mediumtext,
  `Subject` mediumtext,
  `Publisher` mediumtext,
  `Phys_Desc` mediumtext,
  `Call_Number` mediumtext,
  `Edition` mediumtext,
  `Summary` mediumtext,
  `Notes` mediumtext,
  PRIMARY KEY (`Book_ID`),
  KEY `Classification_ID` (`Classification_ID`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`Classification_ID`) REFERENCES `classification` (`Classification_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (101,1,'The Great Gatsby','F. Scott Fitzgerald','Fiction','Scribner','180p','PS3511.I9 G7','1st Edition','A novel about the decadence of the 1920s','Classic American literature'),(102,2,'A Brief History of Time','Stephen Hawking','Science','Bantam Books','212p','QB981 .H38 1988','1st Edition','An introduction to cosmology and the universe','Popular science book'),(103,3,'Autobiography of Malcolm X','Malcolm X','Biography','Ballantine Books','460p','E185.97.L5 A3 1992','1st Edition','The life story of Malcolm X','Civil rights movement'),(104,4,'The World War II Desk Reference','Douglas Brinkley','History','Harper Perennial','896p','D743 .B85 2004','1st Edition','A comprehensive reference on World War II','Military history'),(105,5,'The Selfish Gene','Richard Dawkins','Science','Oxford University Press','360p','QH431 .D28 1976','1st Edition','A classic work on evolutionary biology','Genetics and evolution'),(106,6,'The Design of Everyday Things','Donald A. Norman','Technology','Basic Books','257p','TS171.4 .N67 2013','Revised Edition','A book on user-centered design','Human-computer interaction'),(107,7,'The Art Book','Editors of Phaidon Press','Arts','Phaidon Press','608p','N6490 .A78 2012','1st Edition','A visual guide to art movements and works','Art history'),(108,8,'The Norton Anthology of English Literature','Various Authors','Literature','W.W. Norton & Company','3200p','PR1109 .N6 2006','8th Edition','A comprehensive anthology of English literature','Literary criticism'),(109,9,'The Republic','Plato','Philosophy','Penguin Classics','416p','JC71 .P35 2003','Revised Edition','A Socratic dialogue on justice and the ideal state','Classical philosophy'),(110,10,'The Holy Quran','Abdullah Yusuf Ali','Religion','Amana Publications','1856p','BP109 .A5 2004','3rd Edition','The central religious text of Islam','Islamic scripture');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrow` (
  `Borrow_ID` int NOT NULL,
  `User_ID` int DEFAULT NULL,
  `Book_ID` int DEFAULT NULL,
  `Date_Borrowed` varchar(45) DEFAULT NULL,
  `Date_Due` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Borrow_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
INSERT INTO `borrow` VALUES (1,1001,101,'2023-03-10','2023-04-10'),(2,1002,102,'2023-03-15','2023-04-15'),(3,1003,103,'2023-03-20','2023-04-20'),(4,1004,104,'2023-03-25','2023-04-25'),(5,1005,105,'2023-03-30','2023-04-30'),(6,1006,106,'2023-04-01','2023-05-01'),(7,1007,107,'2023-04-05','2023-05-05'),(8,1008,108,'2023-04-10','2023-05-10'),(9,1009,109,'2023-04-15','2023-05-15'),(10,1010,110,'2023-04-20','2023-05-20');
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification` (
  `Classification_ID` int NOT NULL,
  `Classification` mediumtext,
  PRIMARY KEY (`Classification_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification`
--

LOCK TABLES `classification` WRITE;
/*!40000 ALTER TABLE `classification` DISABLE KEYS */;
INSERT INTO `classification` VALUES (1,'Fiction'),(2,'Non-Fiction'),(3,'Biography'),(4,'History'),(5,'Science'),(6,'Technology'),(7,'Arts'),(8,'Literature'),(9,'Philosophy'),(10,'Religion');
/*!40000 ALTER TABLE `classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `copy`
--

DROP TABLE IF EXISTS `copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `copy` (
  `Barcode` int NOT NULL,
  `Copy` varchar(45) DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `Location` varchar(45) DEFAULT NULL,
  `Format` int DEFAULT NULL,
  `Vendor` varchar(45) DEFAULT NULL,
  `Qbt` varchar(45) DEFAULT NULL,
  `Fund` int DEFAULT NULL,
  `Date_Acq` varchar(45) DEFAULT NULL,
  `Book_ID` int DEFAULT NULL,
  `Accession_Number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Barcode`),
  KEY `Format` (`Format`),
  KEY `Fund` (`Fund`),
  KEY `Book_ID` (`Book_ID`),
  CONSTRAINT `copy_ibfk_1` FOREIGN KEY (`Format`) REFERENCES `format` (`Format_ID`),
  CONSTRAINT `copy_ibfk_2` FOREIGN KEY (`Fund`) REFERENCES `fund` (`Fund_ID`),
  CONSTRAINT `copy_ibfk_3` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`Book_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `copy`
--

LOCK TABLES `copy` WRITE;
/*!40000 ALTER TABLE `copy` DISABLE KEYS */;
INSERT INTO `copy` VALUES (1000001,'Copy 1','Available','MAIN',1,'Vendor A','QBT001',1,'2020-01-01',101,'ACC001'),(1000002,'Copy 2','Checked Out','ANNX',2,'Vendor B','QBT002',2,'2020-02-15',102,'ACC002'),(1000003,'Copy 3','Available','SCI',3,'Vendor C','QBT003',3,'2020-03-20',103,'ACC003'),(1000004,'Copy 4','Checked Out','ARCH',4,'Vendor D','QBT004',4,'2020-04-01',104,'ACC004'),(1000005,'Copy 5','Available','MED',5,'Vendor E','QBT005',5,'2020-05-10',105,'ACC005'),(1000006,'Copy 6','Checked Out','LAW',6,'Vendor F','QBT006',6,'2020-06-15',106,'ACC006'),(1000007,'Copy 7','Available','ENGR',7,'Vendor G','QBT007',7,'2020-07-01',107,'ACC007'),(1000008,'Copy 8','Checked Out','BIZ',8,'Vendor H','QBT008',8,'2020-08-10',108,'ACC008'),(1000009,'Copy 9','Available','MUSC',9,'Vendor I','QBT009',9,'2020-09-20',109,'ACC009'),(1000010,'Copy 10','Checked Out','ARTS',10,'Vendor J','QBT010',10,'2020-10-01',110,'ACC010');
/*!40000 ALTER TABLE `copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fine`
--

DROP TABLE IF EXISTS `fine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fine` (
  `Fine_ID` int NOT NULL,
  `User_ID` int DEFAULT NULL,
  `Amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Fine_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fine`
--

LOCK TABLES `fine` WRITE;
/*!40000 ALTER TABLE `fine` DISABLE KEYS */;
INSERT INTO `fine` VALUES (1,1001,'$5.00'),(2,1002,'$10.00'),(3,1003,'$2.50'),(4,1004,'$7.75'),(5,1005,'$0.00'),(6,1006,'$12.25'),(7,1007,'$3.50'),(8,1008,'$6.00'),(9,1009,'$8.75'),(10,1010,'$4.25');
/*!40000 ALTER TABLE `fine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `format`
--

DROP TABLE IF EXISTS `format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `format` (
  `Format_ID` int NOT NULL,
  `Format` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Format_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `format`
--

LOCK TABLES `format` WRITE;
/*!40000 ALTER TABLE `format` DISABLE KEYS */;
INSERT INTO `format` VALUES (1,'Hardcover'),(2,'Paperback'),(3,'eBook'),(4,'Audiobook'),(5,'DVD'),(6,'Blu-ray'),(7,'CD'),(8,'Vinyl'),(9,'Magazine'),(10,'Newspaper');
/*!40000 ALTER TABLE `format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund`
--

DROP TABLE IF EXISTS `fund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fund` (
  `Fund_ID` int NOT NULL,
  `Fund` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Fund_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund`
--

LOCK TABLES `fund` WRITE;
/*!40000 ALTER TABLE `fund` DISABLE KEYS */;
INSERT INTO `fund` VALUES (1,'General Fund'),(2,'Special Collections'),(3,'Endowment Fund'),(4,'Grant Fund'),(5,'Donation Fund'),(6,'Library Fund'),(7,'Technology Fund'),(8,'Research Fund'),(9,'Student Fund'),(10,'Alumni Fund');
/*!40000 ALTER TABLE `fund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `Location_Acronym` varchar(45) NOT NULL,
  `Location` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Location_Acronym`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES ('ANNX','Annex'),('ARCH','Architecture Library'),('ARTS','Arts Library'),('BIZ','Business Library'),('ENGR','Engineering Library'),('LAW','Law Library'),('MAIN','Main Library'),('MED','Medical Library'),('MUSC','Music Library'),('SCI','Science Library');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record_logs`
--

DROP TABLE IF EXISTS `record_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_logs` (
  `Record_Log_ID` int NOT NULL,
  `User_ID` int DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Record_Log_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_logs`
--

LOCK TABLES `record_logs` WRITE;
/*!40000 ALTER TABLE `record_logs` DISABLE KEYS */;
INSERT INTO `record_logs` VALUES (1,1001,'2023-03-15'),(2,1002,'2023-04-20'),(3,1003,'2023-05-05'),(4,1004,'2023-09-10'),(5,1005,'2023-10-25'),(6,1006,'2023-11-01'),(7,1007,'2024-01-15'),(8,1008,'2024-02-28'),(9,1009,'2024-03-10'),(10,1010,'2024-04-22');
/*!40000 ALTER TABLE `record_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_info`
--

DROP TABLE IF EXISTS `return_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_info` (
  `Return_ID` int NOT NULL,
  `User_ID` int DEFAULT NULL,
  `Book_ID` int DEFAULT NULL,
  `Fine_ID` int DEFAULT NULL,
  `Date_Returned` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Return_ID`),
  KEY `Book_ID` (`Book_ID`),
  KEY `Fine_ID` (`Fine_ID`),
  CONSTRAINT `return_info_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`Book_ID`),
  CONSTRAINT `return_info_ibfk_2` FOREIGN KEY (`Fine_ID`) REFERENCES `fine` (`Fine_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_info`
--

LOCK TABLES `return_info` WRITE;
/*!40000 ALTER TABLE `return_info` DISABLE KEYS */;
INSERT INTO `return_info` VALUES (1,1001,101,1,'2023-04-15'),(2,1002,102,2,'2023-04-20'),(3,1003,103,3,'2023-04-25'),(4,1004,104,4,'2023-04-30'),(5,1005,105,NULL,'2023-05-01'),(6,1006,106,6,'2023-05-05'),(7,1007,107,7,'2023-05-10'),(8,1008,108,8,'2023-05-15'),(9,1009,109,9,'2023-05-20'),(10,1010,110,10,'2023-05-25');
/*!40000 ALTER TABLE `return_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validation`
--

DROP TABLE IF EXISTS `validation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validation` (
  `Validation_ID` int NOT NULL,
  `User_ID` int DEFAULT NULL,
  `Day` varchar(45) DEFAULT NULL,
  `Month` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  `Semester` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Validation_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validation`
--

LOCK TABLES `validation` WRITE;
/*!40000 ALTER TABLE `validation` DISABLE KEYS */;
INSERT INTO `validation` VALUES (1,1001,'15','March','2023','Spring'),(2,1002,'20','April','2023','Spring'),(3,1003,'05','May','2023','Spring'),(4,1004,'10','September','2023','Fall'),(5,1005,'25','October','2023','Fall'),(6,1006,'01','November','2023','Fall'),(7,1007,'15','January','2024','Spring'),(8,1008,'28','February','2024','Spring'),(9,1009,'10','March','2024','Spring'),(10,1010,'22','April','2024','Spring');
/*!40000 ALTER TABLE `validation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-01  3:17:41
